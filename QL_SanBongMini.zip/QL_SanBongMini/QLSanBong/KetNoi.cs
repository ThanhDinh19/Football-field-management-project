﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSanBong
{
    public class KetNoi
    {
        public SqlConnection connect;

        public KetNoi()
        {
            connect = new SqlConnection("Data Source = LAPTOP - P4MA6CJH; Initial Catalog = QL_SanBongMini; Integrated Security = True");

        }

        public KetNoi(string strcn)
        {
            connect = new SqlConnection(strcn);
        }

        public bool checkkey(string s)
        {
            SqlCommand cmd = new SqlCommand(s, connect);
            int count = (int)cmd.ExecuteScalar();
            if (count > 0)
                return false;
            return true;
        }
    }
}
