﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSanBong
{
    public partial class GiaoDienKH : Form
    {
        public GiaoDienKH()
        {
            InitializeComponent();
        }

        private void GiaoDienKH_Load(object sender, EventArgs e)
        {
         
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
